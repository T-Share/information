module.exports = function (grunt) {
	grunt.initConfig({
		pkg: grunt.file.readJSON('package.json'),
		uglify: {
			build: {
				src: ["src/js/common.js", "src/js/new-payment.js"],
				dest: "build_artifacts/build/touch/js/pay/new-payment.0.0.2.js"
			},
			cardFill: {
				src: ["src/js/common.js", "src/js/card-fill.js"],
				dest: "build_artifacts/build/touch/pay/card-fill.0.0.1.js"
			}
		}
	});
	
	grunt.loadNpmTasks('grunt-contrib-uglify');

	grunt.registerTask("defult", ["uglify:build"]);
};