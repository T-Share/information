/**
 * 景区分销
 */
//var template=require('../../../lib/artTemplate/3.0.0/template');
//var tpl = {
// 	sceniclistTpl: require("../../tpl/build/detail/sceniclist")
//};

(function(){
//var parentBox = $(".pack_order");

    var scenery = {
        init: function(){
           scenery.initEvent(); 
           add();
        },
        initEvent: function(){
        	//点击整个页面的时候把请选择日期的下拉框文本和请选择场次的下拉框文本隐藏
        	$(document).on("click","body",function(){
        		$(".input_choose").hide();
        	});

            //下拉框 选择日期，选择场次
            $(document).on("click",".date_box,.screen_box",function(e){
            	
            	e.stopPropagation();
                 var self = $(this);
                 self.find(".input_choose").show();
                 if(self.hasClass("date_box")){ //如果当前点击的是请选择日期的input控件那么把请选择场次的下拉框文本隐藏
                 	$(".screen_box").find(".input_choose").hide();
                 }else{//如果当前点击的是请选择场次的input控件那么把请选择日期的下拉框文本隐藏
                 	$(".date_box").find(".input_choose").hide();
                 }
                 
            });

            //选择日期
            $(document).on("click",".input_choose ul li",function(e){
            	e.stopPropagation();
                 var self = $(this);
                 var parent = self.parent(".J-scenerylistBox");
                 if(!self.hasClass("select")){//判断选择日期的时候是否选择了“请选择日期”这个文字
                   	
                 	var ticketDate = self.find(".ticketDate").text();
                 	var cnAmout = self.find(".cnAmout").text();
                 	self.parents(".date_box").find(".J_date").val(ticketDate);
                 	self.parents(".input_date").siblings(".J-price").find(".buy").empty().append(cnAmout);
                 	self.parents(".input_date").siblings(".J-price").find("small").addClass("hide");
                 	var listBox = self.parents(".J-scenerylistBox");
                 	//进行ajax请求 得到场次
                 	$.ajax({
                 		type:"get",
                 		url:"",
                 		async:true,
                 		success:function(data){
                 			if(data){
                 				self.parents(".input_date").siblings(".input_screen").find("div.screen_box").removeClass("hide");
                 			}
                 		}
                 	});
                 }else{
                 	self.parents(".J-scenerylistBox").find(".numBox").val(0); //如果选择了“请选择日期”的文字，把数量控件中的值置为0
                 	self.parents(".J-scenerylistBox").find(".cho").addClass("hide");
                 	self.parents(".date_box").find(".J_date").val(self.text());
                 	var _this = self.parents(".input_date").siblings(".J-price");
                 	_this.find(".buy").empty().append(_this.find(".buy").attr("data-money"));
                 	_this.find("small").removeClass("hide");
                 
                 }
                 self.parents(".input_choose").hide();
                 
            }); 
            

            //选择场次
            $(document).on("click",".input_screen .input_choose ul li",function(e){
            	e.stopPropagation();
                 var self = $(this);
                 var ticketDate = self.text();
                 self.parents(".screen_box").find(".J_screen").val(ticketDate);
                 self.parents(".input_choose").hide();
            }); 
            
       
  
            
            //减
            $(document).on("click",".J-btnNum .sub_btn",function(){
            	var self = $(this);
            	var parents = self.parents(".num_box");
            	var num = parseInt(parents.children(".numBox").val())-1;
            	parents.children(".numBox").val(num);
            	if(num<=0){
            		parents.children(".sub_btn").addClass("sub_btn_false");
            		parents.children(".numBox").val(0);
            		self.parents(".J-btnNum").siblings(".tips").find(".cho").addClass("hide");
            	}
            });
            
            
            //验证加减按钮,验证日期，场次下拉框
            /**
             * 
             * @param {Object} listBox 当前点击加号的TR列
             */
            function  validateData(listBox){
           /*   var self = $(listBox);
              var flag = false; //数量控件不可以累加 验证不正确
              var date_box = self.children(".input_date");
              var screen_box = self.children(".input_screen").find(".screen_box");
              var tips = self.children(".tips");

				var _J_date = self.find(".J_date");//请选择日期的input控件
				var _J_screen = self.find(".J_screen");//请选择场次的input控件
				var _input_choose_size = self.find(".input_choose ul li").length; //场次的数量
				if(_J_date.val() != "" &&_J_date.val() != "请选择日期"  ){ //日期控件不是请选择日期
					if(_input_choose_size !=0){ //场次控件的文本不等于0
						if(_J_screen.val()!="" && _J_screen.val() != "请选择场次"){ //场次控件的文本不等于0并且选择的不是“请选择场次文本”
							tips.find(".error").addClass("hide");
              	   			date_box.find(".J_date").removeClass("borderOrange");
              	   			screen_box.find(".J_screen").removeClass("borderOrange");
							flag = true; //数量控件可以累加，验证正确
							
						}else{ //场次控件的文本不等于0并且选择的是“请选择场次文本”
							tips.find(".error").removeClass("hide").empty().append("请选择场次哦！");	
							date_box.find(".J_date").removeClass("borderOrange");
							screen_box.find(".J_screen").addClass("borderOrange");
						}
					}else{ //场次控件的文本等于0
						tips.find(".error").addClass("hide");
          	   			date_box.find(".J_date").removeClass("borderOrange");
          	   			screen_box.find(".J_screen").addClass("borderOrange");
						flag = true; //数量控件可以累加,验证正确
					}
				}else{//日期控件是请选择日期
					
					tips.find(".error").removeClass("hide").empty().append("请选择日期哦！");
					if( _J_screen.val() == "请选择场次"){ //如果日期控件是请选择日期然后场次控件文本是“请选择场次”那么添加橙色文本框
						screen_box.find(".J_screen").addClass("borderOrange");
					}else{//如果日期控件是请选择日期然后场次控件文本不是“请选择场次”那么隐藏橙色文本框
						screen_box.find(".J_screen").removeClass("borderOrange");
					}
					date_box.find(".J_date").addClass("borderOrange");  
				}
             	return flag; //返回数量控件可以累加的标志*/
            }


           //查看全部
           $(document).on("click",".J-sceneryInfoDetail .J-more",function(){
            	var self = $(this);
            	self.toggleClass("fold");
            	if(self.hasClass("fold")){
                   self.html("收起<b></b>");
            	}else{
            	   self.html("查看全部<b></b>");
            	}
            });
            
            $(document).on("click",".scenery_box",function(){ //景区的点击显示和隐藏事件
            	var _this = $(this);
            	var parent = _this.parent(".scenery_info");
            	/*_this.parents(".scenery_info").children(".J-sceneryInfoDetail").show().find("tr").show(); //当前景区点击了那么显示当前信息
            	//得到点击当前景区以外的tr的个数
            	var _sceneryDetail_length = _this.parents(".scenery_info").siblings(".scenery_info").find(".sceneryDetail").find("tr").length;
            	
				//得到点击当前景区以外的tr的个数进行循环
            	for(var i=0;i<_sceneryDetail_length;i++){
            		//得到第i个tr列里面的打勾标志对象
            		var _flag=_this.parents(".scenery_info").siblings(".scenery_info").find(".sceneryDetail").find("tr").eq(i).find(".tips").find("i.cho");
            		
            		if(!_flag.hasClass("ok")){//如果票型信息标志不显示的情况
            			_this.parents(".scenery_info").siblings(".scenery_info").find(".sceneryDetail").find("tr").eq(i).hide();//进行隐藏
            		}
            	}*/
//          	var _scenery_info = _this.parents(".scenery_info");
//          	var _J-scenerylistBox  = _scenery_info.find(".J-scenerylistBox");
//          	if(_scenery_info.hasClass("on")){
//          		for(var i= 0 ; i<_J-scenerylistBox){
//          			
//          		}
//          	}

if(!parent.hasClass("on")){
                    parent.addClass("on");
				    parent.siblings().removeClass("on");
				}else{
					parent.removeClass("on");
				   // parent.siblings().addClass("on");
				}

              // _this.parents(".scenery_info").toggleClass("on");

            	
            });
        },
        validateData : function(listBox){
        	
        	   var self = $(listBox);
              var flag = false; //数量控件不可以累加 验证不正确
              var date_box = self.children(".input_date");
              var screen_box = self.children(".input_screen").find(".screen_box");
              var tips = self.children(".tips");

				var _J_date = self.find(".J_date");//请选择日期的input控件
				var _J_screen = self.find(".J_screen");//请选择场次的input控件
				var _input_choose_size = self.find(".input_choose ul li").length; //场次的数量
				if(_J_date.val() != "" &&_J_date.val() != "请选择日期"  ){ //日期控件不是请选择日期
					if(_input_choose_size !=0){ //场次控件的文本不等于0
						if(_J_screen.val()!="" && _J_screen.val() != "请选择场次"){ //场次控件的文本不等于0并且选择的不是“请选择场次文本”
							tips.find(".error").addClass("hide");
              	   			date_box.find(".J_date").removeClass("borderOrange");
              	   			screen_box.find(".J_screen").removeClass("borderOrange");
							flag = true; //数量控件可以累加，验证正确
							
						}else{ //场次控件的文本不等于0并且选择的是“请选择场次文本”
							tips.find(".error").removeClass("hide").empty().append("请选择场次哦！");	
							date_box.find(".J_date").removeClass("borderOrange");
							screen_box.find(".J_screen").addClass("borderOrange");
						}
					}else{ //场次控件的文本等于0
						tips.find(".error").addClass("hide");
          	   			date_box.find(".J_date").removeClass("borderOrange");
          	   			screen_box.find(".J_screen").addClass("borderOrange");
						flag = true; //数量控件可以累加,验证正确
					}
				}else{//日期控件是请选择日期
					
					tips.find(".error").removeClass("hide").empty().append("请选择日期哦！");
					if( _J_screen.val() == "请选择场次"){ //如果日期控件是请选择日期然后场次控件文本是“请选择场次”那么添加橙色文本框
						screen_box.find(".J_screen").addClass("borderOrange");
					}else{//如果日期控件是请选择日期然后场次控件文本不是“请选择场次”那么隐藏橙色文本框
						screen_box.find(".J_screen").removeClass("borderOrange");
					}
					date_box.find(".J_date").addClass("borderOrange");  
				}
             	return flag; //返回数量控件可以累加的标志
        	
       },
//      getScenicList:_getScenicList,
        add :add,
    }

    /**
     * 
     * @param {Object} bookdate 日期
     * @param {Object} days 游玩天数
     * @param {Object} sceneryId 景区ID
     * @param {Object} sceneryName 景区名字
     */
//   function _getScenicList(bookdate,days,sceneryId,sceneryName){
//
//		$.ajax({
//			type: "post", //使用get方法访问后台
//			url: "/tours/GetScenicList", //要访问的后台地址
//			dataType:"json",
//			data: {
//				"bookdate": bookdate,
//				"sceneryId": sceneryId,
//				"days": days,
//				"sceneryName": sceneryName
//			}, //要发送的数据
//			success: function(data) { //msg为返回的数据，在这里做数据绑定
//				if(data){
//               // $(".J-sceneryInfoDetail").html($(template("sceneryInfoTmpl",data)));
//               var seneryInfo = $.extend({}, data);
//               for(var i = 0 ; i<seneryInfo.Tickets; i++){
//				   seneryInfo.Tickets[i].TicketPrices[0].ContainedItems = data.Tickets[i].TicketPrices[0].ContainedItems;
//               }
//                $(".J-sceneryInfoDetail").html($(tpl.sceniclistTpl(seneryInfo)));
//				}
//			},
//			error: function(data){
//
//			}
//		});
//      
//   }

          
            //加
            function add(){
            	$(document).on("click",".J-btnNum .add_btn",function(){
            	var self = $(this);
            	var parents = self.parents(".num_box");
            	var listBox = self.parents(".J-scenerylistBox");
          		var _flag = scenery.validateData(listBox); //flag:true :验证正确 false:验证不正确
            	if(_flag){ //验证正确数量控件中的值进行加一
            		var num = parseInt(parents.children(".numBox").val())+1;
            	    parents.children(".numBox").val(num);
            	    parents.children(".sub_btn").removeClass("sub_btn_false");
            	}
            	if(_flag && parents.children(".numBox").val()>=1){ //如果验证正确并且数量控件中的值不等于0那么显示绿色的打勾标志
            		self.parents(".J-btnNum").siblings(".tips").find(".cho").removeClass("hide");
            		var _record = self.parents(".J-scenerylistBox").attr("data-record");
            		/*console.log("_record:"+_record);
            		console.log("length:"+self.parents(".J-sceneryInfo").find("tr").length);
            		for(var i= 0 ; i<self.parents(".J-sceneryInfo").find("tr").length; i++){
            			var _record1 = self.parents(".J-sceneryInfo").find("tr").eq(i).attr("data-record");
            			console.log("_record1:"+_record1);
            			var unedit = self.parents(".J-sceneryInfo").find("tr").eq(i).attr("data-status");
            			if(_record == _record1 &&  unedit =="unedit"){
            				self.parents(".J-sceneryInfo").find("tr").eq(i).addClass("ok");
            			}
            		}*/
            		
            		var x = self.parents(".J-scenerylistBox ").siblings("tr[data-record="+_record+"]")
            			.index();
            			self.parents(".J-sceneryInfo").find("tr").eq(x).addClass("ok");
            		console.log("x"+x);
            		aa(listBox);
            	}
            
            	
            });
            }

function aa(parent){
	var self = $(parent);
	var _cho = self.find(".tips .cho").hasClass("hide");
	var string = "";
	var value = {};
	if(!_cho){
		var price = self.find(".J-price .buy").text();
		var num = self.find(".J-btnNum .numBox").val();
		var name = self.find(".sceneryTitle").text();
	}
	
	var value = {
		price : price,
		num : num,
		name : name
	}

	 string = string + 
	 "<dd class='price_box'>"+
	 "<span class='price_item'>"+name+"</span>"+
	 "<strong class='price_detail'><dfn>¥</dfn>"+
	  price + "<span>&nbsp;x&nbsp;" + num + "</span></strong></dd>";
	 alert(string);
	 alert(value.price);
}

     scenery.init();

//   module.exports = scenery;

})();
