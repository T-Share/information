;(function () {
    //require('../../../common/js/mid');
   /* var lvguUrl = require('../../../common/js/lvgu');
    var initsdk = require('../../../common/js/initsdk');
    var track = require('../../../common/js/track');
    var UrlQuery = require('../../../common/js/urlquery');
    var touchmove = require('../../../common/js/touchmove'); //弹层背部内容不滚动
    var tpl = {
        linelistTpl: require("../../tpl/build/list/linelist")
    };
*/
    var isApp              = gnyCommon.isApp;
    var location_city      = $.cookie("gny_location_city");//定位城市
    var locCId             = location_city>0?location_city:"";      //搜索埋点  locCId
    var current_src_cityid = $.cookie("gny_current_src_cityid");    //选择城市
    var cityId             = current_src_cityid>0?current_src_cityid:""; //搜索埋点 cityId
    var abauto             = $.cookie("abauto") == 'old' ? 0 : 1;//ab标识
    var gnyAB              = $.cookie("GNYAB")?$.cookie("GNYAB"):""; //搜索新老架构 1表示新 0表示老
    var destCityName       = $('#DestCityName').val();
    var totalCount         = $('#TotalCount').val(); //结果数
    var backNum            = 0; //返回按钮点击次数
    var ScrollMap          = {};
   // var urlQuery           = new UrlQuery();
    //var channel            = urlQuery.get("channel");

    //存储上一次的遍历参数
    var paramsMap = {
        dest: destCityName,
        src: $('#DepCityName').val(),
        prop: $("#hidProp").val(),
        sort: 1,
        start: 1,
        lbl3: $("#hidLbl3").val()
    };

    var listView = {
        init: function(){
            FastClick.attach(document.body);//fastclick
            listView.initEv();
            listView.initEvent(); //页面绑定事件
        },
        initEv: function(){
            //目的地切换，如果选中了某个城市，要把这边的数据保存下来，根据这个session值来判断是否高亮
            if (gnyCommon.session("destCho") == 1) {
                var parent = ".dialog-des";
                var child = ".des-screen";
                if (parent == ".dialog-des") {
                    if ($(parent + ' .left-elem .green').length > 0) {
                        $(child).addClass('active');
                    } else {
                        $(child).removeClass('active');
                    }
                }
            }

            //目的地切换默认选中第一个
            if ($('.dialog-des .left-elem .cho').length == 0) {
                $('.dialog-des .left-elem li').eq(0).addClass('cho');
                $('.dialog-des .right-elem ul').eq(0).removeClass('none');
            }


            //时间天数，综合筛选选中第一个数据
            $('.dialog-play .left-elem li').eq(0).addClass('cho');
            $('.dialog-play .right-elem ul').eq(0).removeClass('none');
            $('.dialog-syn .left-elem li').eq(0).addClass('cho');
            $('.dialog-syn .right-elem ul').eq(0).removeClass('none');

        },
        initEvent: function(){

            //筛选面板
            $('.tab-bottom')
                .on('touchend', '.sure', clickSure) //确定
                .on('touchend', '.cancel', clickCancel) //取消
                .on('touchend', '.clear', clickClear) //清空筛选
                .on('click, tap', '.left-elem li', function(){
                    clickLeftPanel($(this));
                }) //左边的筛选
                .on('click, tap', '.dialog-des .right-elem li', clickRightPanel) //目的地切换右边的筛选
                .on('click, tap', '.dialog-play .right-elem li, .dialog-syn .right-elem li', function(){
                    //把出游人数的筛选标签置为0
                    $('.playLineBox a.J_lineLabel[data-parent=J_travelBox]').attr('data-flag','0');
                    clickNorRightPanel($(this));
                })//时间天数，综合筛选右边的筛选
                .on('click', '.tab-ul li', clickBotPanel) //底部切换
                .on('click', '.dialog-sort li', clickSort) //综合排序
                .on('click', '.playLineBox a.J_screenLabel', clickLineBox)//同程专线,优惠筛选标签
                .on('click','.playLineBox a.J_lineLabel',clickLabelBox);//筛选标签

            //tab标签切换
            $('.tab-area').on("click", "li", function(e) {
                var data_href = $(this).find("a").attr("href");
                //如果是同程专线，点击tab切换的时候加上同程标签参数请求时区分
                if (location.search.indexOf("lbl6428=6231") != -1) {
                    data_href = data_href + "&lbl6428=6231";
                }
                location.replace(data_href);
                //产品tab埋点
                var trackValue = $(this).find("a").text();
               // track("Touch_gnylist", "Tab", trackValue, "click");
            });

            $('.tab-area li').on('click, tap', clickTopPanel); //顶部切换
            $('.J_CityMask').on('touchend', clickMaskCancel); //点击遮罩取消

            $(window).on('scroll', function() {
                var scrollHeight = $(window).scrollTop();
                var windowHeight = $(window).height();
                var documentHeight = $('body').height() - 100;
                var flag = scrollHeight > 45;

                $('.tab-box').toggleClass('tab-fixed', flag);
                $('.go-top').toggle(flag);

                list.showTab(); //scroll里面的回调是在滚动结束之后
                if (scrollHeight + windowHeight > documentHeight && list.addMore) {
                    list.ajaxItems(); //滚动到底部,加载下一页
                }

            });


            //点击重新筛选
            $('.reScreen').on('click, tap', function() {
                choBotPanel(list.nowIndex);
            });

            //点击返回顶部
            $('#goTop').on('click, tap', function() {
                $(window).scrollTop(0);
            });

            //无直达线路的关闭
            $('.tip-close').on('click, tap', function() {
                $('.tip-tag').hide();
            });


            //列表页点击进详情
            $('.searchResult').on("click", "a", function() {
                var clickIndex = $(this).index() + 1;
                var lineId = $(this).data('url');
                var trackValue = "|*|pos:" + clickIndex + "|*|k:" + destCityName + "|*|locCId:" + locCId + "|*|pjId:2011|*|cityId:" + cityId + "|*|resId:" + lineId + "|*|ab:" + gnyAB + "|*|";
                //track("search", "/detail", trackValue, "/tourism/list");
            });

            //排序
            $('.dialog-sort ul li').click(function() {
                var trackValue = "|*|k:" + destCityName + "|*|locCId:" + locCId + "|*|cityId:" + cityId + "|*|ab:" + gnyAB + "|*|";
               // track("search", "/sort", trackValue, "/tourism/list");
            });

            //返回按钮埋点
            $(".page-back").click(function() {
               // track("Touch_gnylist", "Back", backNum++, "click");
            });

            //产品列表埋点事件
            $("body").on("click", ".item", function() {
                var _this = $(this);
                var _index = _this.index() + 1;
                var value = "listview";
                value += "^" + ["全部", "跟团游", "", "自由行", "", "目的地参团"][$("#hidProp").val() || 0]; //Tab名称
                value += "^" + _index; //在列表的位置
                value += "^" + _this.attr("data-url"); //线路id
                value += "^" + $("#DepCityName").val(); //定位城市
                value += "^" + destCityName; //搜索词
                value += "^" + ["综合排序", "综合排序", "精品热销", "价格从高到低", "", "价格从低到高"][paramsMap.sort || 0]; //排序条件
                value += "^" + getFilterParam("lpCity"); //筛选条件之一，出发城市
                value += "^" + getFilterParam("lbl28"); //筛选条件之一，游玩线路（可多选）
                value += "^" + getFilterParam("lbl6232"); //筛选条件之一，同程专线
                value += "^" + getFilterParam("lbl3"); //筛选条件之一，游玩天数
                value += "^" + getFilterParam("pm"); //筛选条件之一，出发日期(可多选)
                value += "^" + getFilterParam("lbl5"); //筛选条件之一，交通工具（可多选）
                value += "^" + getFilterParam("lbl9"); //筛选条件之一，价格区间
                value += "^" + getFilterParam("lbl7"); //筛选条件之一，住宿条件
                value += "^" + getFilterParam("lbl481"); //筛选条件之一，购物特色
                value += "^" + _this.attr("data-istczx"); //产品是否同程专线，1为是，0为否

                //track('Touch_gnylist', 'Line_list', value, 'click');
            });
        },
    };
    $(function(){
        listView.init();
    });

    //点击同程专线
    function clickLineBox(e) {
        var ele = $(this);
        ele.toggleClass("on");
        var trackValue = location_city + "^"+ ele.text();
       // track("Touch_gnylist", "Filter_ tab", trackValue, "click");
    }

    //点击筛选标签
    function clickLabelBox(e){
        var ele = $(this);
        ele.toggleClass("on");
        var parent = ele.attr("data-parent");
        if (parent != "J_travelBox") {
            clickLeftPanel($('.left-elem li.' + parent)); //综合筛选左边（交通工具，购物特色）
        }
        var id = ele.attr("data-id");
        ele.attr("data-flag","1");
        //时间天数（行程天数），综合筛选（交通工具，购物特色）右边
        clickNorRightPanel($('.right-elem li[data-id="' + id + '"]'));
        var trackValue = location_city + "^"+ ele.text();
       // track("Touch_gnylist", "Filter_ tab", trackValue, "click");
    }


    //筛选切换(综合排序)
    function clickSort(e) {
        var text = $(this).find('.sort-record').text();
        var param = $(this).data('param');
        $('.sort-screen').toggleClass('active',param != 1);
        $('.dialog-sort li').removeClass('active');
        paramsMap.sort = $(this).attr('data-param');
        list.ajaxItems(1);
        $(this).addClass('active');
        $('.sort-screen b').text(text);
        list.hidePanel();
        //综合排序，排序规则埋点
        //track("Touch_gnylist", "Reorder", text, "click");
    }

    //点击确定按钮[目的地切换&时间天数&综合筛选]
    function clickSure(e) {
        var parent = $(this).attr('data-parent');
        var li = $("." + parent).children(".pro-box").find(".left-elem ul li .pro-name");
        var child = parent.replace('dialog-', '') + '-screen';
        if (parent == 'dialog-des') {
            var li_active = $('.dialog-des .right-elem .active');
            list.dest = li_active.text();
            var data_href = li_active.find("a").attr("href");
            if (list.dest == "全部") {
                list.dest = li_active.attr('data-pname');
            }
            //如果是目的地切换就重定向
            if (list.dest) {
                list.isLocalStorageSupported("destCho");
                location.replace(data_href);
                gnyCommon.session("destCho", 1);
            }
        } else {
            list.screenMap();
            list.ajaxItems(1, true);
            list.tabTurnGreen('.' + parent, '.' + child);
            list.hidePanel();
        }
        e.preventDefault();//阻止浏览器默认事件

        //线路玩法二级筛选埋点
        if(parent == "dialog-play"){
            var _this = $(".playLineBox a.tcLineLabel");
            var _arr = [{
                    txt: '行程天数',
                    val: 'lbl3'
                },
                {
                    txt: '出发时间',
                    val: 'pm'
                }
            ];
            var text = _this.hasClass("on") ? _this.text() : 0;//同程专线
            var trackValue = location_city + "^" + text;
            //track('Touch_gnylist', 'Second_play', trackValue , 'click');

            $.each(li,function(i,v){
                var _index = $(v).attr('data-key');
                var value = location_city + '^' +_arr[_index - 1].txt + '^' + getFilterParam(_arr[_index - 1].val);
                //track('Touch_gnylist', 'Second_play', value, 'click');
            });
        }

        //综合筛选二级筛选埋点
        if(parent == "dialog-syn"){
            var _arr = [
                {
                    txt: '出发城市',
                    val: 'lpCity'
                },
                {
                    txt: '价格区间',
                    val: 'lbl9'
                },
                {
                    txt: '交通工具',
                    val: 'lbl5'
                },
                {
                    txt: '游玩线路',
                    val: 'lbl28'
                },
                {
                    txt: '购物特色',
                    val: 'lbl481'
                }
            ];
            $.each(li,function(i,v){
                var _index = $(v).attr('data-key');
                var value = location_city + '^' +_arr[_index - 1].txt + '^' + getFilterParam(_arr[_index - 1].val);
               // track('Touch_gnylist', "Second_comprehensive", value , 'click');
            });
        }
    }

    //点击取消按钮
    function clickCancel(e) {
        var parent = '.' + $(this).attr('data-parent');
        var child = parent.replace('dialog-', '') + '-screen';
        list.reHistory(parent);
        list.tabTurnGreen(parent, child);
        when_Tour_hide_SynPlay($(".tab-area li.active").index());//目的地参团不显示出发城市
        e.preventDefault();//阻止浏览器默认事件
        if(parent == ".dialog-syn"){
            $(parent).find(".sure").attr("data-selected" , "0");
        }
    }

    function clickMaskCancel(e) {
        if (!$('.dialog-sort').hasClass('none')) { //如果选中的是排序面板,nowPanel里面是没有存储筛选栏的
            list.hidePanel();
        } else {
            list.reHistory(list.nowPanel);
        }
        e.preventDefault();//阻止浏览器默认事件
    }

    //点击清空按钮
    function clickClear(e) {
        var scrollName = $(this).attr('data-parent');
        var parent = '.' + $(this).attr('data-parent');
        var child = parent.replace('dialog-', '') + '-screen';
        $(parent + ' .left-elem li').removeClass('green');
        $(child).removeClass('active');
        $(parent + ' .left-elem li').removeClass('cho');

        $(parent + ' .left-elem li').eq(0).addClass('cho');
        $(parent + ' .right-elem ul').addClass('none');
        $(parent + ' .right-elem ul').eq(0).removeClass('none');


        $(parent + ' .right-elem ul').each(function() {
            $(this).find('li').removeClass('active');
            $(this).find('li').removeClass('active-elem');
            $(this).find('li').eq(0).addClass('active');
        });

        //如果是目的地切换清空筛选，删除session
        if(parent == '.dialog-des'){
            list.isLocalStorageSupported("destCho");
        }

        if (parent == '.dialog-syn') {
            $(".playLineBox a").removeClass("on");
        }

        if (parent == '.dialog-play') {
            $('.enter').removeClass('active');
            $('#earlistDepTime').text('最早出发时间');
            $('#latestDepTime').text('最晚出发时间');
        }
        var scrollNameL = scrollName + 'L';
        var scrollNameR = scrollName + 'R';
        ScrollMap[scrollNameL].scrollToElement(parent + ' .left-elem .cho', 100);
        ScrollMap[scrollNameR].refresh();
        ScrollMap[scrollNameR].scrollToElement(parent + ' .right-elem .active', 100);
        when_Tour_hide_SynPlay($(".tab-area li.active").index());//目的地参团不显示出发城市
        e.preventDefault();//阻止浏览器默认事件
    }

    function clickLeftPanel(elem) {
        var scrollName = elem.parent().parent().attr('data-parent');
        var parent = '.' + elem.parent().parent().attr('data-parent');
        $(parent + ' .left-elem li').removeClass('cho');
        elem.addClass('cho');

        var index = elem.children('.pro-name').attr('data-key');
        var trackValue = elem.children(".pro-name").text();
        $(parent + ' .right-elem ul').addClass('none');
        $(parent + ' .right-elem .c' + index).removeClass('none');
        var scrollNameR = scrollName + 'R';
        ScrollMap[scrollNameR].refresh();
        ScrollMap[scrollNameR].scrollToElement(parent + ' .right-elem .c' + index + ' .active', 100);

        //线路玩法，左边筛选埋点
        if(scrollName == "dialog-play"){
            //track("Touch_gnylist", "Line_play", trackValue, "click");
        }
        //综合筛选，左边筛选埋点
        if(scrollName == "dialog-syn"){
            //track("Touch_gnylist", "Comprehensive_screening", trackValue, "click");
        }

        if (parent != '.dialog-play' || parent != '.dialog-syn') {
            return;
        }
        if ($(parent + ' .right-elem .c' + index + " li").eq(0).hasClass('active')) {
            elem.removeClass('green');
        } else {
            elem.addClass('green');
        }
    }

    function clickRightPanel(e) {
        var ele = $(this);
        var parent = '.' + ele.parent().parent().parent().attr('data-parent');
        $(parent + ' .left-elem li').removeClass('green');
        $(parent + ' .right-elem li').removeClass('active');
        ele.addClass('active');

        if (ele.index() !== 0) {
            $(parent + ' .left-elem .cho').addClass('green');
        }
        categoryEvent($('#DepCityID').val(), ele.data("provinceid"), ele.data("id"));
    }

    function clickNorRightPanel(elem) {
        var parent = '.' + elem.parent().parent().parent().attr('data-parent');
        var index = $(parent + ' .left-elem .cho .pro-name').attr('data-key');
        var id = elem.attr("data-id");//筛选的id
        var tabLabel =  $('.playLineBox a.J_lineLabel[data-id="' + id + '"]');//筛选标签
        var dayLabel = $('.playLineBox a.J_lineLabel[data-parent=J_travelBox]');//出游天数标签
        var dayID =  dayLabel.attr("data-id");//出游天数筛选标签的id
        var flag = dayLabel.attr("data-flag");//1:筛选标签的出游天数 0: 时间天数中行程天数的筛选

        /*单选面板*/
        if ($(parent + ' .right-elem .c' + index).hasClass('single')) {
            $(parent + ' .right-elem .c' + index + ' li').removeClass('active');
            elem.addClass('active');

            //判断行程天数是否选择出游天数的筛选标签
            if (!tabLabel.hasClass('on')) { //筛选标签不选中
                if (id == dayID && flag != 1) {
                    tabLabel.addClass('on');//添加选中
                } else {
                    dayLabel.removeClass('on');//删除选中
                    if (flag == 1) {
                        elem = $('.right-elem li[data-label=lbl3]');
                        elem.addClass('active').siblings().removeClass('active');
                    }
                }
                //把出游人数的筛选标签置为0
                dayLabel.attr('data-flag','0');
            }

            //如果右边的筛选不是全部，就把左边的筛选置为原点的绿色
            if (elem.index() !== 0) {
                $(parent + ' .left-elem .cho').addClass('green');
            } else {
                $(parent + ' .left-elem .cho').removeClass('green');
            }

        } else {
            // 复选面板
            if (elem.index() !== 0) {
                $(parent + ' .right-elem .c' + index + ' li').eq(0).removeClass('active');
                elem.toggleClass('active-elem');

                if ($(parent + ' .right-elem .c' + index + ' .active-elem').length != 0) {
                    $(parent + ' .left-elem .cho').addClass('green');
                    tabLabel.toggleClass('on', elem.hasClass('active-elem'));
                } else {
                    $(parent + ' .left-elem .cho').removeClass('green');
                    $(parent + ' .right-elem .c' + index + ' li').eq(0).addClass('active');
                    tabLabel.removeClass('on');
                }
            } else {
                $(parent + ' .right-elem .c' + index + ' li').removeClass('active-elem');
                elem.addClass('active');
                $(parent + ' .left-elem .cho').removeClass('green');
                tabLabel.removeClass('on');
            }
        }
        if (parent == '.dialog-play') {
            $('.dialog-play .right-elem .c' + index + ' .enter').removeClass('active');  //单选面板的enter也要去掉active
            $('.dialog-play .right-elem .c' + index + ' #earlistDepTime').text('最早出发时间');
            $('.dialog-play .right-elem .c' + index + ' #latestDepTime').text('最晚出发时间');
        }
    }

    //tab切换事件
    function clickTopPanel() {
        var index = $(this).index();
        choTopPanel(index);
    }

    //展开选中的顶部tab
    function choTopPanel(index) {
        $('.tab-area li').removeClass('active');
        $('.tab-area li').eq(index).addClass('active');
        $(window).scrollTop(0);

        if (list.nowIndex == "0" || list.nowIndex == "1" || list.nowIndex == "2" || list.nowIndex == "3") {
            list.beforeIndex = list.nowIndex;
        }
        list.nowIndex = index;
        paramsMap.prop = $('.tab-area li').eq(index).attr('data-param');
        list.ajaxItems(1);
        list.showTab();
    }

    //目的地参团的时候不显示线路&交通
    function when_Tour_hide_SynPlay(index) {
        //目的地参团的时候
        if (index == 3) {
            //线路
            if ($.trim($(".dialog-syn .left-elem li").eq(0).text()) == "出发城市") {
                if ($(".dialog-syn .left-elem li").eq(0).hasClass("cho")) {
                    $(".dialog-syn .left-elem li").eq(1).addClass("cho");
                    $(".dialog-syn .right-elem ul").eq(1).removeClass("none");
                    if (!$(".dialog-syn .left-elem li").eq(0).siblings().hasClass("green")) {
                        $(".syn-screen").removeClass("active");
                    }
                }
                $(".syn-screen .left-elem li").eq(0).hide().removeClass("cho").removeClass("green");
                $(".syn-screen .right-elem ul").eq(0).addClass("none");
                $(".syn-screen .right-elem ul").eq(0).find("li").eq(0).addClass("active").siblings().removeClass("active");
            }

            //交通工具
            if ($.trim($(".dialog-syn .left-elem li").eq(1).text()) == "交通工具") {
                if ($(".dialog-syn .left-elem li").eq(1).hasClass("cho")) {
                    $(".dialog-syn .left-elem li").eq(0).addClass("cho");
                    $(".dialog-syn .right-elem ul").eq(0).removeClass("none");
                    if (!$(".dialog-syn .left-elem li").eq(1).siblings().hasClass("green")) {
                        $(".syn-screen").removeClass("active");
                    }
                }
                $(".dialog-syn .left-elem li").eq(1).hide().removeClass("cho").removeClass("green");
                $(".dialog-syn .right-elem ul").eq(1).addClass("none");
                $(".dialog-syn .right-elem ul").eq(1).find("li").eq(0).addClass("active").siblings().removeClass("active-elem");
            }
        } else {
            //线路
            $(".dialog-syn .left-elem li").eq(0).show().addClass("cho").siblings().removeClass("cho");
            $(".dialog-syn .right-elem ul").eq(0).removeClass("none").siblings().addClass("none");
            //交通工具
            $(".dialog-syn .left-elem li").eq(2).show();
        }
    }

    function clickBotPanel() {
        var child = '.' + $(this).attr('data-parent');
        var scrollName = $(this).attr('data-parent');
        choBotPanel(child, scrollName);
        //点击的筛选选项埋点
        var trackValue = $(this).find("b").text();
        //track("Touch_gnylist", "FooterTab", trackValue, "click");
    }

    //展开选中的底部tab
    function choBotPanel(child, scrollName) {
        if (child != '.dialog-sort') {
            list.cloneUser = $(child + ' .pro-box').clone();
            list.nowPanel = child;      //记录下当前的展开面板
            list.nowIndex = child;
             
            if(child == '.dialog-play' || child == '.display-syn'){
                list.cloneLineBox = $(child + ' .playLineBox').clone();
            }

            /*if (child == '.dialog-syn' && $(".playLineBox a").html()) {//线路玩法同程专线
                list.cloneLine = $(".playLineBox a").html();
            }*/
        }
        list.showPanel();
        $(child).removeClass('none');

        //综合筛选（同程专线等标签可以左右滚动）
        if(child == '.dialog-syn' && $(".playLineBox a").length > 0){
            gnyCommon.asynLoad("iScroll", function () {
                var iScroll = new IScroll('.playLineBox', {
                    scrollX: true
                });
            });
        }

        if (child != '.dialog-sort') {
            var scrollNameL = scrollName + 'L';
            var scrollNameR = scrollName + 'R';

           gnyCommon.asynLoad("iScroll", function() {
                var index = $(child + ' .left-elem .cho .pro-name').attr('data-key');
                ScrollMap[scrollNameL] = new IScroll(child + ' .left-elem', {
                    mouseWheel: true,
                    scrollbars: false,
                    click: true,
                    tap: 'myTap'
                });
                ScrollMap[scrollNameR] = new IScroll(child + ' .right-elem', {
                    mouseWheel: true,
                    scrollbars: false,
                    click: true,
                    tap: 'myTap'
                });

               ScrollMap[scrollNameL].scrollToElement(child + ' .left-elem .cho', 100);
               ScrollMap[scrollNameR].scrollToElement(child + ' .right-elem .c' + index + ' .active', 100);
            });
        }
        when_Tour_hide_SynPlay($(".tab-area li.active").index());//目的地参团不显示出发城市
    }

    var list = {
        start: 1,
        pageSize: 10,
        addMore: true,
        refid: getRefid(),
        beforeIndex: 0,
        goToNativeUrl: "//shouji.17u.cn/internal/inland/line",
        goToListUrl: "//shouji.17u.cn/internal/inland/searchlist",
        dataInit: function () {
            list.getLocationDep();

            FastClick.attach(document.body);
            if (gnyCommon.session("saveHistory") == "true") {
                $('.tab-screen').remove();
                $('.tab-bottom').empty();
                $(gnyCommon.session("tabHistory")).appendTo('.tab-bottom');

                var tabIndex = gnyCommon.session("tabIndexHistory");
                $('.tab-area li').removeClass('active');
                $('.tab-area li').eq(tabIndex).addClass('active');
                list.screenMap();
                list.ajaxItems(1);
                var height = Number(gnyCommon.session("scrollHeight"));
                $(window).scrollTop(height);
                gnyCommon.session("saveHistory","false");
            }
            list.goToUrl();
            list.wemallshare();
            return this;
        },
        //分享
        wemallshare: function () {
            var Mid = gnyCommon.session("Mid");
            var urlQuery = new gnyCommon.urlQuery();
            var shareUrl = "";

            if (Mid) {
                urlQuery.set("Mid", Mid);
                shareUrl = urlQuery.fullurl();

                if (!urlQuery.get('Mid')) {
                    urlQuery.set("Mid", Mid);
                    shareUrl = urlQuery.fullurl();
                }
            }
            else {
                shareUrl = location.href;
            }

            var conf = {
                url: shareUrl,
                img: "//img1.40017.cn/touch/cn/guoneiyou/wechat/wxshare.jpg",
                title: "想要会员特权？想要低价国内游？赶快来微店下单吧！尊享同程国内游会员特权...",
                desc: "想要会员特权？想要低价国内游？赶快来微店下单吧！尊享同程国内游会员特权..."
            };

           // initsdk(conf);
        },
        screenMap: function () {
            paramsMap = {
                dest: destCityName,
                src: $('#DepCityName').val(),
                prop: $("#hidProp").val(),
                sort: 1,
                start: 1,
                lbl3: $("#hidLbl3").val()
            };
            $.extend(paramsMap, {
                prop: $('.tab-areah.active').attr('data-param'),
                sort: $('.dialog-sort .active').attr('data-param')
            });
            $.extend(paramsMap, list.screenChild('.dialog-play'));
            $.extend(paramsMap, list.screenChild('.dialog-syn'));
        },
        screenChild: function (parent) {
            var leftNode = $(parent + ' .left-elem .green');
            var paramObject = {};
            var paramsObject = {};
            leftNode.each(function () {
                var leftIndex = $(this).find('.pro-name').attr('data-key');
                var childNode = $(parent + ' .right-elem .c' + leftIndex);
                var mapKey = childNode.attr('data-parent');
                var childNodeActive = childNode.find('.active');
                var childNodeElem = childNode.find('.active-elem');
                var mapValue = childNodeActive.attr('data-id');
                var minPrice = childNodeActive.attr('data-min');
                var maxPrice = childNodeActive.attr('data-max');
                //单选面板
                if (mapValue) {
                    paramObject[mapKey] = mapValue;

                } else {
                    //复选面板
                    var mapValue = [];
                    childNodeElem.each(function () {
                        if ($(this).attr('data-id') !== null) {
                            mapValue.push($(this).attr('data-id'));
                        }
                    });
                    paramObject[mapKey] = mapValue.join(',');
                }

                if (minPrice) {
                    paramObject.minPrice = minPrice;
                }

                if (maxPrice) {
                    paramObject.maxPrice = maxPrice;
                }

                $.extend(paramsObject, paramObject);
            });

            if (parent == '.dialog-play') {
                var earlistDepTime = $('#earlistDepTime').text();
                var latestDepTime = $('#latestDepTime').text();
                if (/^\d{4}[-]\d{2}[-]\d{2}$/.test(earlistDepTime)) {
                    paramsObject.minSDate = earlistDepTime;
                }
                if (/^\d{4}[-]\d{2}[-]\d{2}$/.test(latestDepTime)) {
                    paramsObject.maxSDate = latestDepTime;
                }
            }
            if (parent == ".dialog-syn") {
                //同程专线
                $(".playLineBox a.tcLineLabel.on").each(function (index, elem) {
                    paramsObject[$(elem).data("label")] = $(elem).data("id");
                });

                //优惠标签
                if($(".playLineBox a.J_favorLabel").hasClass("on")){
                    paramsObject.disCount = 1;
                }else{
                    paramsObject.disCount = 0;
                }     

            }
            return paramsObject;
        },
        changeUrl: function (index) {
            var url = location.href;
            if (url.indexOf('?') < 0) {
                url += '?';
                url += "dest=" + index;
            } else {
                if ((/dest=(.*?)&/).test(url)) {
                    url = url.replace(/dest=(.*?)&/, "dest=" + index + "&");
                } else {
                    url = url.replace(/dest=(.*)/, "dest=" + index);
                }
            }

            url = url.replace('?&', '?');
            location.replace(url);
        },
        showPanel: function () {
            $('.go-top').css('display', 'none');
            $('.panel').addClass('none');
            $('.J_CityMask').css('display', 'block');
            $('body').css('overflow-y', 'hidden');
           //touchmove.disableScroll();//禁止滚动
        },
        hidePanel: function () {
            //pc手机模拟器里会出现类似于点透的问题，导致跳转详情页，这里加了点延迟
            setTimeout(function () {
                $('.J_CityMask').css('display', 'none');
                $('.panel').addClass('none');
                $('body').css('overflow-y', 'auto');  //面板关闭的时候,内容可以正常滚动
            }, 350);
           // touchmove.enableScroll();//放开滚动
        },
        reHistory: function (parent) {
            var child = parent.replace('dialog-', '') + '-screen';
            $(parent + ' .pro-box').remove();
            $(parent).append(list.cloneUser);

             if(parent == '.dialog-play' || parent == '.display-syn'){
                 $(parent + '.playLineBox').remove();
                 $(parent).append(list.cloneLineBox);
            }

           /* if (parent == ".dialog-syn" && list.cloneLine) {
                $(".playLineBox a").html(list.cloneLine);
            }*/
            list.tabTurnGreen(parent, child);
            list.hidePanel();
        },
        tabTurnGreen: function (parent, child) {
            if (parent != '.dialog-play' && parent != '.dialog-syn') {
                return;
            }
            if (parent == ".dialog-play") {
                if ($(parent + ' .left-elem .green').length > 0 ) {
                    $(child).addClass('active');
                } else {
                    $(child).removeClass('active');
                }
            } else if (parent == ".dialog-syn") {
                if ($(parent + ' .left-elem .green').length > 0 || $(".playLineBox a.on").length > 0) {
                    $(child).addClass('active');
                     // $(parent).find(".sure").attr("data-selected","1");
                } else {
                    $(child).removeClass('active');
                     // $(parent).find(".sure").attr("data-selected","0");
                }
            }
        },
        screenNoResult: function () {
            var screen_noresult = $('#screenNoResult');
            $('.searchResult').css('display', 'none');
            screen_noresult.css('display', 'block');
            screen_noresult.find(".reScreen").css('display', 'inline-block');

            $('#goTop').hide();
            $('.data-loader').css('display', 'none');
        },
        searchResult: function () {
            $('.searchResult').css('display', 'block');
            $('#screenNoResult').css('display', 'none');
            $('.data-loader').css('display', 'block');
        },
        showTab: function () {
            $('.tab-box').show();
            $('.tab-screen').show();
            $('body').css('margin-bottom', '45px');
        },
        hideTab: function () {
            $('.tab-box').hide();
            $('.tab-screen').hide();
            $('#goTop').hide();
            $('body').css('margin-bottom', '0');
        },
        screenHistory: function () {
            gnyCommon.session("tabHistory", $('.tab-bottom').clone().html());
            gnyCommon.session("tabIndexHistory", $('.tab-area .active').index());
            gnyCommon.session("scrollHeight", $(window).scrollTop());
        },
        /**
         * 获取当前定位出发城市
         */
        getLocationDep: function () {

            var city = $.cookie("gny_current_src_city");
            var isList = $("#IsList").val() == 1 ? true : false;
            if (city || isList) return;
            var t;
            $.ajax({
                url: "/guoneiyou/list/getlocation",
                dataType: "json",
                success: function (res) {
                    var time = 10;
                    var ele_depCity = $(".J_depCity");
                    var ele_countDown = $(".J_countDown");

                    if (res.ret == "ok") {
                        ele_depCity.html(decodeURI($.cookie("gny_current_src_city")));
                        t = setInterval(function () {
                            time = time - 1;
                            if (time <= 0) {
                                clearInterval(t);
                                location.reload();
                            }
                            ele_countDown.html(time + "秒");
                        }, 1000);
                    } else {
                        $(".J_location_dep").hide();
                    }
                },
                error: function () {
                    $(".J_location_dep").hide();
                }
            });
        },
        setTitle: function () {
            //修改头部文案
            var url = location.href;
            var headText = "国内游";
            if (destCityName != "") {
                headText = url.indexOf("refer=sem") == -1 ? (destCityName + '(共' + totalCount + '条)') : destCityName;
            } else {
                headText = '国内游(共' + totalCount + '条)';
            }
            gnyCommon.setNavbarTitle(headText);
        }
    };

    list.getData = function (param, callback) {
        var url = "/guoneiyou/List/GetNextPageData?isApp=" + gnyCommon.appVersion;
        if (new gnyCommon.urlQuery().get("lbl6428") == "6231") {
            url += "&lbl6428=6231";
        }
        $.ajax({
            type: "GET",
            url: url,
            data: param,
            dataType: 'json',
            success: function (obj) {
                obj && (obj.page = param.start);
                (typeof callback == "function") && callback(obj)
            },
            error: function () {
                console.log("ajax error");
            }
        });
    };

    list.appendItems = function (obj, parent) {
        //模板里面拼接的需要是json数据
        var arr_ProductList = {
            ProductList: [],
            refid: list.refid,
            page: obj.page
        };
        var propType = ["", "跟团游", "", "自由行", "", "目的地参团"];
        var classType = ["", "package", "", "free", "", "tour"];

        $(obj.lineList).each(function (i, value) {
            value.propType = propType[value.prop];
            value.classType = classType[value.prop];
            if ($.inArray("321同程旅游节", value.labelTips) >= 0) {
                value.crown = 0;
            }
            arr_ProductList.ProductList.push(value);
        });

        $(tpl.linelistTpl(arr_ProductList)).appendTo(parent);
        loadWebp({
            attr:'data-nsrc',
            img: $(parent).find("[data-page='" + obj.page + "'] img"),
            replace:true
        });

        IOS_safari();
    };

    //兼容IOS safari
    function IOS_safari() {
        if ($(".searchResult .item").length < 5) {
            $(".content").css("padding-bottom", ($(window).height() - $(".list-area").height()) + "px");
        } else {
            $(".content").css("padding-bottom", "0px");
        }
    }

    list.ajaxItems = function (page, isFilter) {
        if (page == '1') {
            list.start = 1;
            paramsMap.start = 1;
            list.addMore = true;
        } else {
            if (list.isLoading) return;
            list.start++;
            paramsMap.start = list.start;

            //列表页翻页埋点
            var trackValue = "|*|k:" + destCityName + "|*|locCId:" + locCId + "|*|cityId:" + cityId + "|*|page:" + list.start + "|*|ab:" + gnyAB + "|*|";
            //track("search", "/page", trackValue, "/tourism/list");
        }
        list.isLoading = true;
        //判断是不是目的地参团  是的话筛选条件去除线路&交通
        if ($(".tab-area li.active").index() == 3) {
            paramsMap.lpCity = "";
            paramsMap.ve = "";
        }

        list.getData(paramsMap, function (obj) {
            if (page == '1') {
                totalCount = obj.totalCount;
                $('#TotalCount').val(totalCount);
                //如果是过滤 则埋点
                if(isFilter){
                    trackValue = "|*|k:" + destCityName + "|*|locCId:" + locCId + "|*|cityId:" + cityId + "|*|rc:" + totalCount + "|*|ab:" + gnyAB + "|*|";
                    //track("search", "/filter", trackValue, "/tourism/list");

                    //filter后 要执行列表显示事件埋点
                    trackValue = "|*|k:" + destCityName + "|*|locCId:" + locCId + "|*|cityId:" + cityId + "|*|rc:" + totalCount + "|*|ab:" + gnyAB + "|*|";
                   // track("search", "/show", trackValue, "/tourism/list");
                }
                if (obj.lineList.length) $(window).scrollTop(0);
                $('.searchResult').empty();
                if (obj.lineList.length == 0) {
                    list.screenNoResult();
                } else {
                    list.searchResult();
                }
                list.setTitle();
            }


            if (obj.lineList.length < list.pageSize) {
                $('.data-loader').empty();
                $('<p class="noMore">没有更多产品啦</p>').appendTo('.data-loader');
                list.addMore = false;
            } else {
                $('.data-loader').empty();
                $('<p class="loading"><i></i>正在努力游入</p>').appendTo('.data-loader');
            }
            list.appendItems(obj, '.searchResult');
            list.isLoading = false;
        });
    };

    list.isGoToNative = function (proType, routeVer) {
        if (window._tc_bridge_public.isTc
            && window._tc_bridge_public.isAppVersionGreatThan(751)
            && proType != 3
            && proType != 4
            && routeVer != 0) {
            return true;
        }
        return false;
    };
    list.isLocalStorageSupported =function(key){
        var testKey = 'test',
        storage = window.sessionStorage;
        try {
            storage.setItem(testKey, 'testValue');
            storage.removeItem(testKey);

            sessionStorage.removeItem(key);
            return true;
        } catch (error) {
            $.cookie(key,null);
            return false;
        }
    };
    list.goToUrl = function () {
        $("body").on("click", ".item", function (e) {
            e.preventDefault();
            gnyCommon.session("saveHistory","true");
            list.screenHistory();
            var proType = $(this).attr('pro-type');
            var routeVer = $(this).attr('route-ver');
            var datacity = $(this).attr('data-city');
            var dataurl = $(this).attr('data-url');
            var property = $(this).attr('property');
            var pos = $(this).index() + 1;      //点击的位置 pos
            var mid = gnyCommon.session("Mid");    //微店标志 mid不为空 则为微店 不跳App
            //获取资源的类型,活动产品要在详情页添加,如果机票动态打包（8月底做好）、火车票活包（9月份做）,就跳转H5,否则跳转native
            if (!mid && list.isGoToNative(proType, routeVer)) {
                location.href = list.goToNativeUrl + "?lineId=" + $(this).attr('data-url') + "&sessionId=" + $.cookie("_tourismsid") + "&moduleId=" + gnyCommon.session("moduleId");

            } else {

                var url = "";
                if (parseInt(proType) < 3) {
                    url = "/guoneiyou/line/t" + property + "j1p" + dataurl + "c0.html?action=list&pos=" + pos;
                } else {
                    url = "/guoneiyou/line/t" + property + "j" + proType + "p" + dataurl + "c" + datacity + ".html?action=list&pos=" + pos;
                }

                if (channel == "lvgu"){
                    url = lvguUrl.sildehref(url);

                }

                location.href = url;

            }
        });
        return this;
    };

    list.choDate = function () {
        var isIOS = (/iphone|ipad/gi).test(navigator.appVersion);
        gnyCommon.asynLoad('mobiScroll', function() {
            $.each(['earlistDepTime', 'latestDepTime'], function(i, v) {
                $("#"+v).mobiscroll('destroy').mobiscroll({
                    id: v,
                    dateOrder: 'yymmdd',
                    dateFormat: 'yy-mm-dd',
                    preset: "date",
                    theme: isIOS ? "ios7" : "android-ics light",
                    mode: "scroller",
                    display: "bottom",
                    lang: "zh",
                    onSelect: function (date) {
                        checkDate(date, this);
                    }
                });
            });
        });

        function checkDate(date, that) {
            var id = $(that).attr('id');
            var las = new Date($('#latestDepTime').text()).getTime();
            var ear = new Date($('#earlistDepTime').text()).getTime();
            var now = new Date(date).getTime();

            if (id == 'earlistDepTime' && now > las) {
                $('#earlistDepTime').text('最早出发时间');
                $(that).removeClass('active');
            } else if (id == 'latestDepTime' && now < ear) {
                $('#latestDepTime').text('最晚出发时间');
                $(that).removeClass('active');
            } else {
                $('#' + id).text(date);
                $(that).addClass('active');
            }
            $('.J_FlowBox li').removeClass('active');
            $('.J_FlowBox li').removeClass('active-elem');
            $('.dialog-play .left-elem .cho').addClass('green');
        }
        return this;
    };

    // 无线BDC事件统计
    function categoryEvent(portCityID, provinceID, destCityID) {
        if (!isApp) return;
        var jsonObj = {
            "param": {
                "category": "221",//此项参数值需要找数据中心申请，目前对接人是 支夏萍
                "action": "4",
                "optLabel": "selectlist",
                "optValue": portCityID + "|" + provinceID + "|" + destCityID + "|", // 出发城市|目的省份|目的城市|主题（暂留空）
                "eventType": "0",//"0":默认,原来的事件类别统计；"1":调用资源访问数据接口SDKResourceData.743添加
                "pagename": "国内游列表页"
            },
            "CBPluginName": "_tc_web_util",//回调，自定义
            "CBTagName": "set_category_event"//回调自定义
        }

        if (window._tc_bridge_util && (typeof window._tc_bridge_util.set_category_event === "function")) {
            window._tc_bridge_util.set_category_event(jsonObj)
        }
    }

    list.dataInit()         //第一次进入页面时候的数据加载
        .choDate();         //日期选择面板

    var timer = setInterval(function () {
        if (window._tcTraObj) {
            var gny_search_btn = gnyCommon.session("gny_search_btn");
            var gny_search_frompage = gnyCommon.session("gny_search_frompage");
            var trackValue;
            if (gny_search_btn == "click") {
                list.isLocalStorageSupported("gny_search_btn");
                list.isLocalStorageSupported("gny_search_frompage");

                trackValue = "|*|k:" + destCityName + "|*|locCId:" + locCId +
                    "|*|cityId:" + cityId + "|*|rc:" + totalCount + "|*|ab:" + gnyAB + "|*|";
                track("search", "/sbox/k", trackValue, "/tourism/homepage", gny_search_frompage);
            }

            //列表显示事件埋点
            trackValue = "|*|k:" + destCityName + "|*|locCId:" + locCId + "|*|cityId:" + cityId + "|*|rc:" + totalCount + "|*|ab:" + gnyAB + "|*|";
            //track("search", "/show", trackValue, "/tourism/list");

            clearInterval(timer);
        }
    }, 1000);

    IOS_safari();


    function getFilterParam(label) {
        var _this = $("[data-parent= " + label + "]");
        var choose = _this.find(".active");
        var labels = [];
        var text = "";
        if (_this.find(".active-elem").length > 0) {
            labels = _this.find(".active-elem");
            $.each(labels, function (i, v) {
                if (i == labels.length - 1) {
                    text += $.trim($(this).text());
                } else {
                    text += $.trim($(this).text()) + ",";
                }
            });
        } else if (choose.attr("data-label") == parent) {
            text = $.trim(choose.text());
        } else if (choose.length > 0) {
            text = $.trim(choose.text());
        } else{
            text = $("[data-id='" + paramsMap[label] + "']").text();
        }
        return text || 0;
    }

})();
