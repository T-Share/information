
$(function(){

	var _wall 	= $("#Wall");
	var speed 	= 100;
	$.each(proArr, function(index, item){
		(function(index,item){
			setTimeout(function(){
				var html = ''
				+ 	'<li class="inline animated slideInLeft">'
				+		'<a href="' + item.href + '">'
				+			'<h2>图标</h2>'
				+			'<p>' + item.name + '</p>'
				+		'</a>'
				+	'</li>';
				_wall.find("ul").append(html)
			}, index*speed);
		})(index, item)
	});








});