;(function() {
	// require('./hovermask.js');
	// if ($().hovermask) {
		$('#HoverMask > li').each(function() {
			$(this).hovermask({
				speed: 200,
				easing: 'ease-in-out'
			});
		});
	// }
})();
