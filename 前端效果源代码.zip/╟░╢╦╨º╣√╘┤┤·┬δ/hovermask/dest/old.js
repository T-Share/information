		// //鼠标进入事件
		// $(document).on('mouseenter', '#LiFather li', function() {
		// 	var that = $(this);
		// 	var thisX = that.offset().left;
		// 	var thisY = that.offset().top;
		// 	var difX = coordinate.x - thisX;
		// 	var difY = coordinate.y - thisY;
		// 	var thisW = that.width();
		// 	var thisH = that.height();
		// 	var direction = '';
		// 	console.log('x : %d, y : %d, thisX: %d, thisY: %d', coordinate.x, coordinate.y, thisX, thisY);
		// 	if (difX >= 0 && difY <= 0 && difX <= thisW) { //from-top
		// 		direction = 'top';
		// 		// that.removeClass().addClass('top');
		// 	} else if (difX >= 0 && difY >= 0 && difX >= thisW) { //from-right
		// 		direction = 'right';
		// 		// that.removeClass().addClass('right');
		// 	} else if (difX >= 0 && difY >= 0 && difY >= thisH) { //from-bottom
		// 		direction = 'bottom';
		// 		// that.removeClass().addClass('bottom');
		// 	} else if (difX <= 0 && difY >= 0 && difY <= thisH) { //from-left
		// 		direction = 'left';
		// 		// that.removeClass().addClass('left');
		// 	}
		// 	that.removeClass().addClass('from-' + direction);
		// });

		// //鼠标移出事件
		// $('body').on('mouseleave', '#LiFather li .mask', function() {
		// 	$(this).parents('li').removeClass('from-top from-right from-bottom from-left');
		// });
		// // $('body').on('mouseleave', '#LiFather li', function() {
		// // 	$(this).removeClass('from-top from-right from-bottom from-left');
		// // });

		// render(liMask.data);