/**
 * name: hover蒙层随鼠标方向滑入滑出
 * author: sh34458 2016.10.13
 * 用法：
 * if ($().hovermask) {
 *		$('#HoverMask > li').each(function() {
 *			$(this).hovermask();
 *		});
 *  }
 * $('#HoverMaskask')为$('li')的包裹层，$('li')内需有一块div蒙层，用来显示，样式自行控制
 * 配置项：
 * options = ｛
 * 		speed: 300,//速度
 * 		easing: 'ease'//贝塞尔曲线
 * ｝
 */
'use strick';
(function() {
	$.HoverMask = function(options, element) {
		this.$ele = $(element);
		this.init(options);
	};

	$.HoverMask.defaults = {
		speed: 300,
		easing: 'ease'
	};

	$.HoverMask.prototype = {
		init: function(options) {
			// options
			this.options = $.extend(true, {}, $.HoverMask.defaults, options);
			// transition properties
			this.transitionProp = 'all ' + this.options.speed + 'ms ' + this.options.easing;
			//load the events
			this.loadEvents();
		},
		loadEvents: function() {
			let self = this;
			this.$ele.on('mouseenter.hovermask, mouseleave.hovermask', function(event) {
				let $ele = $(this),
					$hoverEle = $ele.find('div'),
					direction = self.getDir($ele, {
						x: event.pageX,
						y: event.pageY
					}),
					style = self.getStyle(direction);
				if (event.type === 'mouseenter') {
					$hoverEle.hide().css(style.from);
					$hoverEle.show(0, function() {
						let $el = $(this);
						$el.css('transition', self.transitionProp);
						self.applyAnimation($el, style.to, self.options.speed);
					});
				} else {
					$hoverEle.css('transition', self.transitionProp);
					self.applyAnimation($hoverEle, style.from, self.options.speed);
				}
			});
		},
		getDir: function($ele, coordinates) {
			let w = $ele.width(),
				h = $ele.height(),
				x = (coordinates.x - $ele.offset().left - (w / 2)) * (w > h ? (h / w) : 1),
				y = (coordinates.y - $ele.offset().top - (h / 2)) * (h > w ? (w / h) : 1),
				direction = Math.round((((Math.atan2(y, x) * (180 / Math.PI)) + 180) / 90) + 3) % 4;
			return direction;
		},
		getStyle: function(direction) {
			let fromStyle, toStyle,
				slideFromTop = {
					left: '0px',
					top: '-100%'
				},
				slideFromBottom = {
					left: '0px',
					top: '100%'
				},
				slideFromLeft = {
					left: '-100%',
					top: '0px'
				},
				slideFromRight = {
					left: '100%',
					top: '0px'
				},
				slideTop = {
					top: '0px'
				},
				slideLeft = {
					left: '0px'
				};
			switch (direction) {
				case 0:
					// from top
					fromStyle = slideFromTop;
					toStyle = slideTop;
					break;
				case 1:
					// from right
					fromStyle = slideFromRight;
					toStyle = slideLeft;
					break;
				case 2:
					// from bottom
					fromStyle = slideFromBottom;
					toStyle = slideTop;
					break;
				case 3:
					// from left
					fromStyle = slideFromLeft;
					toStyle = slideLeft;
					break;
			}
			return {
				from: fromStyle,
				to: toStyle
			};
		},
		applyAnimation: function($el, style, speed) {
			$el.stop().css(style, $.extend(true, [], {
				'animation-duration': speed + 'ms'
			}));
		}
	};

	$.fn.hovermask = function(options) {
		let instance = $(this).data('hovermask');
		this.each(function() {
			if (instance) {
				instance.init();
			} else {
				instance = $(this).data('hovermask', new $.HoverMask(options, this));
			}
		});
	};
	// module.exports = HoverMask;
})();
