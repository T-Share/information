Spine-DEMO
=============

Rendering a Spine animation with EaselJS(CreateJS 100+kb) / min2d(created by Kenko, just 13kb) / pixi(287kb)

EaselJS and min2d just support region attachment. pixi supports all types of attachments
