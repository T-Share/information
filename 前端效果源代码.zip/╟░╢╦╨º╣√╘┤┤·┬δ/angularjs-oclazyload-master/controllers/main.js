/**
 * mainCtrl
 * Created by pkcms.cn on 2016/6/24.
 */
(function () {
    "use strict"
    app.controller("mainCtrl", mainCtrlFn);
    function mainCtrlFn() {
        this.value = "Hello World";
    }
}())