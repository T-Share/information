# angularjs-oclazyload
Angular-ocLazyLoad-Demo

Angular-ocLazyLoad-Demo Article Url : http://blog.pkcms.cn/angularjs-oclazyload/

Just a simple demo for Angular dynamic load and use other modules with ocLazyLoad
