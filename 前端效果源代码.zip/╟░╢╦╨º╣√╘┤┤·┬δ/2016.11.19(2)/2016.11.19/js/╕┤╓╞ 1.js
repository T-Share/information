;(function() {

var aa = {
	data:{},
	init :  function(){
		var self = this;
		self.initEvent();
//		self.getTimeList();
//		self.getAddList();
//		self.getSceneryList();
		self.getCommonList($(".J-list-box"));
	},
	initEvent: function(){
		var self = this;
		$(".J-select").on('change',function(){
			var _parent = $(this).parents(".other-resource").attr("id");
			self.getCommonList($("#"+_parent + ' .J-list-box'));
		})
	},
	//限制赠送
	getTimeList: function(){
		var self = this;
		$(".J-time-box .J-list-box").each(function(item,index){
		  self.data[index] = {
		  	typeName : $(this).data("type"),
		  	details : {
		  		name : $(this).find(".J-name").text(),
		  		count:$(this).find(".J-selectNum").val(),
		  		price: $(this).find(".J-price").text(),
		  	}
		  }
		  console.log(self.data);
		});
	},
	//附加资源
	getAddList: function(){
		var self = this;
		$(".J-add-box .J-list-box").each(function(item,index){
		  self.data[index] = {
		  	typeName : $(this).data("type"),
		  	details : {
		  		name : $(this).find(".J-name").text(),
		  		count:$(this).find(".J-selectNum").val(),
		  		price: $(this).find(".J-price").text(),
		  	}
		  }
		  console.log(self.data);
		});
	},
	//景区资源
	getSceneryList: function(){
		var self = this;
		$(".J-scenery-box .J-list-box").each(function(item,index){
		  self.data[index] = {
		  	typeName : $(this).data("type"),
		  	details : {
		  		name : $(this).find(".J-name").text(),
		  		count:$(this).find(".J-select-group").val(),
		  		price: $(this).find(".J-price").text(),
		  	}
		  }
		  console.log(self.data);
		});
	},
	getCommonList: function(listName){
		var self = this;
		var $listName = listName;
		$listName.each(function(item,index){
		  self.data[index] = {
		  	typeName : $(this).data("type"),
		  	details : {
		  		name : $(this).find(".J-name").text(),
		  		count:$(this).find(".J-select").val(),
		  		price: $(this).find(".J-price").text(),
		  	}
		  }
		  console.log(self.data);
		});
	}
}

aa.init();

})();