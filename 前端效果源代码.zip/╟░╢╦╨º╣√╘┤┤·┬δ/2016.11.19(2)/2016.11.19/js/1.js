;(function() {
var resObj = {};

var aa = {
	init :  function(){
		var self = this;
		self.initEvent();
		self.getCommonList($(".J-list-box"));
	},
	initEvent: function(){
		var self = this;
		$(".J-select").on('change',function(){
		  var _this = $(this);
          var _value = _this.val();
          var _parent = _this.parents('.J-list-box');
          var data = _parent.find('.J-data').data('value');
          console.log(data)
          data.count = _value;
		  self.getCommonList(_parent);
		})
	},
	//获取其他资源列表
	getCommonList: function(list){
			var _price = 0;
			var _arr = [];
			$.each(list, function(i, t) {
				var res = $(this).data("value");
				console.log(res)
				if ($.inArray(res.typeName, Object.keys(resObj)) + 1) {
					//得到点击的对应的价格
					if($.inArray(res.typeName, Object.keys(resObj))){
						_arr.push(resObj[res.typeName].resList);
						$.each(_arr, function(i,v) {
							if(_arr[i].id == res.id){
								_price = _arr[i].price;
							}
						});
					}
//					resObj[res.typeName].resList.splice($.inArray(res.id, Object.keys(resObj)),1);
					resObj[res.typeName].resList.push(res);
					resObj[res.typeName].price += res.price * res.count;
				} else {
					
					resObj[res.typeName] = {
						price: 0,
						resList: []
					}
					
					resObj[res.typeName].resList.push(res);
					resObj[res.typeName].price = res.price * res.count;
				}
				
				return resObj;
			});
			console.log(resObj)
	   // self.getNewList(arr);
	},


}

aa.init();

})();