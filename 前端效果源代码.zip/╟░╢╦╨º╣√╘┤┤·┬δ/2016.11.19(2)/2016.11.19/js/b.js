$(function(){
	var a = [
		{num:1,type:'a'},
		{num:2,type:'b'},
		{num:3,type:'c'},
		{num:4,type:'d'}
	];
	var b = [
		{typeName:'a',details : {name : 'aa',count:11}},
		{typeName:'a',details : {name : 'bb',count:22}},
		{typeName:'b',details : {name : 'cc',count:33}},
		{typeName:'c',details : {name : 'dd',count:44}},
		{typeName:'d',details : {name : 'ee',count:55}},
		{typeName:'d',details : {name : 'ff',count:66}}
	];
	
	var c = [];
//	console.log($.extend(false, a, b))
	for(var i = 0 ;i< a.length ;i++){
		var obj = [];
		for(var j=0;j< b.length;j++){
			if(a[i].type == b[j].typeName){
//				obj = b[j].details;
//				console.log(obj);
//				obj = $.extend(true, obj, b[j].details);
				obj.push(b[j].details);
			}
//			console.log(obj);
//			console.log("--")
		}
		c[i] = {
			num: a[i].num,
			type: a[i].type,
			details:obj
		}
	}
//	$.each(c, function(i,v) {
//		console.log(c)
//		console.log(c[i].num+"-"+c[i].type+"-"+c[i].details[0].name+"-"+c[i].details[0].count);
//		for(var j=0;j<){
//			
//		}
////		console.log(c[i].num+"-"+c[i].type+"-"+c[i].details[1].name+"-"+c[i].details[1].count)
//	});
	for(var i=0;i<c.length;i++){
		console.log(c[i].num+"-"+c[i].type)
		for(var j=0;j<c[i].details.length;j++){
			console.log(c[i].details[j].name+"-"+c[i].details[j].count)
		}
	}
});