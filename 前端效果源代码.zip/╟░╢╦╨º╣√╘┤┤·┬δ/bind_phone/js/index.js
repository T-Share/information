define([ 'app','jquery'], function (app) {
	  
//  app.directive('myTelephone', function () {
//      return {
//          templateUrl:  "view/revise_phone_1.html"
//
//      };
//  });
    
    
 
//require(['app','js/bind_phone'],function(){});

});