define(['jquery','angular', 'angular-resource','angular-animate','angular-ui-router'],function($,angular){
	
	var app = angular.module('telephoneApp', ['ngResource','ngAnimate','ui.router']);
	
	app.init = function(){
		angular.bootstrap(document,['telephoneApp']);
	};
	
	app.directive('myTelephone', function () {
        return {
            templateUrl:  "view/revise_phone_1.html"

        };
    });
    
	app.config(function($stateProvider,$urlRouterProvider){
		$stateProvider.state("bind",{
			url: "/bind",
			templateUrl: "view/bind.html"
		})
		.state("bind.phone_1",{
			url : "/phone_1",
			templateUrl : "view/bind-phone_1.html"

		})
		.state("bind.phone_2",{
			url : "/phone_2",
			templateUrl : "view/bind-phone_2.html"
			
	        
		})
		.state("bind.phone_3",{
			url : "/phone_3",
			templateUrl : "view/bind-phone_3.html",
			controller: function () {
	        	$(".revise_process a").eq(1).removeClass("active");
				$(".revise_process a").eq(2).addClass("active");
	        }
		})
		$urlRouterProvider.otherwise("/bind/phone_1");
	});
	require(['jquery','js/bind_phone'],function(){
//		app.init();
	})
    return app;
	
});