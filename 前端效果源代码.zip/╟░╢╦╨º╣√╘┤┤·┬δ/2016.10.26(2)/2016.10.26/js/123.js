$(function(){
    var $slider = $(".slider");
    var $img = $slider.find(".slider-con").children("li");
    var $navBtn = $(".sliderNav").find("li");
    var timer = null;
    var now = -1;

    $navBtn.hover(function () {
        now = $(this).index();
        auto(now);
    }, function () {
    });

    $slider.hover(function () {
        clearInterval(timer);
    }, function () {
        timer = setInterval(function() {
            now++;
            if(now == $img.length) {now = 0;}
            auto(now);
        },3000);
      /*  $navBtn.eq(0).addClass("active").siblings().removeClass("active");
         $img.eq(0).stop(true, true).fadeIn("slow").siblings().stop(true, true).fadeOut("slow");*/
    }).trigger("mouseleave");


    // Prev
    $(".slider .prev").click(function() {
        now -= 1;
        if(now == -1) {now = $img.length - 1;}
        auto(now);
    });

    // Next
    $(".slider .next").click(function() {
        now += 1;
        if (now == $img.length) {now = 0;}
        auto(now);
    });

    function auto(now) {
        $navBtn.eq(now).addClass("active").siblings().removeClass("active");
        $img.eq(now).stop(true, true).fadeIn("slow").siblings().stop(true, true).fadeOut("slow");
    }
});
