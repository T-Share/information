$(function(){
    var s = new GnySlider("#Slider", {
        onPrev: function() {
            var self = this;
            self.nav.stop(true, true).animate({
                scrollTop : (self.current > 2 ? 67*3 : 0)
            }, 500);
        },
        onNext: function() {
            var self = this;
            self.nav.stop(true, true).animate({
                scrollTop : (self.current > 2 ? 67*3 : 0)
            }, 500);
        }
    });

    $("#Slider").on("click", ".arrow", function() {
        s[$(this).data("action")]();
    });
});
