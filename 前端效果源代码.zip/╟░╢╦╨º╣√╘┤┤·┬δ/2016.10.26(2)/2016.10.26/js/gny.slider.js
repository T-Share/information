(function(window, $) {
    function GnySlider(con, opt) {
        var config = $.extend({}, {
            navType             : "thumb",
            contentSelector     : ".slider-content",
            contentItemSelector : ".slider-content li",
            navClass            : "slider-nav",
            effect              : "fade",
            direction           : "left",
            action              : "mouseover",
            displayTitle        : true,
            intervalTime        : 3000,
            speed               : 500,
            onPrev              : function() {},
            onNext              : function() {}
        }, opt || {});

        this.container = $(con);

        this.get = function(key) {
            return config[key];
        };

        this.set = function(key, value) {
            config[key] = value;
        };

        this.init();
    }

    GnySlider.prototype = {
        constructor: GnySlider,

        init: function() {
            var self = this;
            self.renderSliders();
            self.renderNav();

            self.next();
        },

        renderSliders: function() {
            var self    = this;
            var sliders = self.sliders = $(self.get("contentItemSelector"));
            var effect  = self.get("effect");

            if (effect !== "fade") {
                sliders.each(function(i) {
                    $(this).css("position", "absolute").toggle(!i);
                });
            }

            self.current = -1;
            self.total = sliders.length;
        },

        renderNav: function() {
            var self    = this;
            var navtype = self.get("navType");

            if (navtype == "none") return;

            var navHTML = self.sliders.map(function(i, dom) {
                switch (navtype) {
                    case "thumb" :
                        return "<li><img src='"+ ($(dom).data("thumb") || $(dom).find("img").attr("src")) +"'></li>";
                        break;
                    case "number" :
                        return "<li>"+(i+1)+"</li>";
                        break;
                    default :
                        return "<li></li>";
                        break;
                }
            }).get().join("");

            self.nav = $("<ul>")
                .addClass(self.get("navClass"))
                .html(navHTML)
                .appendTo(self.container)
                .on(self.get("action"), "li", function() {
                    clearTimeout(self.play);
                    self.current = $(this).index();
                    self.switchSlider.call(self);
                });
        },

        switchSlider: function(index) {
            var self    = this;
            var index   = index === undefined ? self.current : index;
            var speed   = self.get("speed");
            var sliders = self.sliders;
            var nav     = self.nav;

            self.current = index = index >= self.total ? 0 : index;
            self.current = index = index < 0 ? self.total-1 : index;

            clearTimeout(self.play);

            sliders.stop(true, true).fadeOut(speed).eq(index).stop(true, true).fadeIn(speed);
            nav && nav.find("li").eq(index).addClass("active").siblings(".active").removeClass("active");

            self.interval();
        },

        interval: function() {
            var self = this;
            self.play = setTimeout(function() {
                self.next();
            }, self.get("intervalTime"));
        },

        prev: function() {
            this.switchSlider(this.current-1);
            this.get("onPrev").call(this);
        },

        next: function() {
            this.switchSlider(this.current+1);
            this.get("onNext").call(this);
        }
    };

    window.GnySlider = window.GnySlider || GnySlider;
})(window, jQuery);
