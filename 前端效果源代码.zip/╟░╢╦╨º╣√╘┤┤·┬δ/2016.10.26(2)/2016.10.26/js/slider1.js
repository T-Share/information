$(function(){
    var _mainSlider = $("#mainslider");
    var _prev = _mainSlider.find(".J-prevBtn");
    var _slider = _mainSlider.slider({//�õ�
        showNav: "orange",
        circle: false,
        moveTime: 5000,
        arrows: true,
        prevBtn: ".J-prevBtn",
        nextBtn: ".J-nextBtn",
        prevFn: function (_slider) {
            if(!_slider.index){
                _prev.addClass("end")
            } else {
                _prev.removeClass("end");
            }

        },
        nextFn: function() {
            _prev.removeClass("end");
        }

    });

    _prev.click(function(){
        if(!_slider.index && $(this).is(".end")){
            var length = _mainSlider.find(".mSlider_nav li").size();
            _slider.scrollTo(length - 1);
        }
    });

});
