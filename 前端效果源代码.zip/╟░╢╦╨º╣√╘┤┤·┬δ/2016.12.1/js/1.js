
$(document).ready(function(){

    // չʾ�Ƶ귿�������б�
    $('body')
        .on('click', '.J-IsShowPolicy', function(){
            var $el = $(this);
            var $p = $el.closest('.J-HotelTypeBox');
            var $table = $p.find('.J-HotelTable');
            showDetail($el);
        })

        //ѡ��ͬ����
        .on('click', '.J-MaskChooseBtn', function () {
            var $el = $(this);
            var _type = $el.closest('tr').data('hoteltype');
            var _table = $el.closest('table');
            var $this = $el.closest('.J-HotelTypeBox').find('.J-IsShowPolicy');
            var _allroom  = _table.find('.J-AllRoomInfo[data-hoteltype = '+_type+']'); //����ѡ����ͬһ�������з���
            var selPrice =  $el.closest('tr').find('.J-PriceDiffer').data('price'); //ѡ��ļ۸�

            if (!$el.hasClass('active')) {
                $el.toggleClass('active').closest('tr').siblings().find('.J-MaskChooseBtn').removeClass('active');
               // self.renderPriceD(selPrice,_allroom); //����
            }
            
            $el.closest('tr').addClass('selected').siblings().removeClass('selected');
            
            $el.closest('table').find('.tr-first[data-hoteltype = '+_type+']').addClass('selected').siblings('.tr-first').removeClass('selected');
            
            _table.find('tr.selected').show().siblings().not('.selected').hide();
            
            $this.removeClass('active');
            
        })


      //չ���Ƶ귿������
//  function showDetail ($el) {
//      var $p = $el.closest('.J-HotelTypeBox');
//      var $td = $p.find('.J-IsShowHotelDetail');
//      var $table = $el.closest(".J-HotelTable");
//      
//      $p.toggleClass('fold');
//      if ($el.hasClass('active')) {
//          $td.attr('rowspan', 2);
//      } else {
//          $td.attr('rowspan', $td.attr('data-policylength'));
//      }
//      $el.toggleClass('active');
//  }
	function showDetail ($el) {
        var $p = $el.closest('.J-HotelTypeBox');
        var $td = $p.find('.J-IsShowHotelDetail');
        var $table = $p.find(".J-HotelTable tr");
        $p.toggleClass('fold');
        if ($el.hasClass('active')) {
//          $td.attr('rowspan', 2);
            console.log($table)
            $p.find('.J-HotelTable tr.selected').show().siblings().not('.selected').hide();
        } else {
//          $td.attr('rowspan', $td.attr('data-policylength'));
            console.log($table)
            $p.find('.J-HotelTable tr').show();
        }
        $el.toggleClass('active');
    }

});

