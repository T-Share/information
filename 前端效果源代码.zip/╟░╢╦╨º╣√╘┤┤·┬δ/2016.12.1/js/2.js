$(document).ready(function() {
	$('body')
		.on('click', '.J-IsShowPolicy', function() {
			var $el = $(this);
			var $p = $el.closest('.J-HotelTypeBox');
			var $table = $p.find('.J-HotelTable');
			showDetail($el);
		})
		.on('click', '.J-MaskChooseBtn', function() {
			var $el = $(this);
			var _type = $el.closest('tr').data('hoteltype');
			var _table = $el.closest('table');
			var $this = $el.closest('.J-HotelTypeBox').find('.J-IsShowPolicy');
			var _allroom = _table.find('.J-AllRoomInfo[data-hoteltype = ' + _type + ']'); //����ѡ����ͬһ�������з���
			var selPrice = $el.closest('tr').find('.J-PriceDiffer').data('price'); //ѡ��ļ۸�

			if(!$el.hasClass('active')) {
				$el.toggleClass('active').closest('tr').siblings().find('.J-MaskChooseBtn').removeClass('active');
				// self.renderPriceD(selPrice,_allroom); //����
				$el.closest('tr').show().end().closest('tr').siblings("tr").hide();
			} else {
				$el.closest('tr').show().end().closest('tr').siblings("tr").hide();
			}
		});

	function showDetail($el) {
//		var $p = $el.closest('.J-HotelTypeBox');
//		var $td = $p.find('.J-IsShowHotelDetail');
		var $xx = $(".J-MaskChooseBtn");
//		$p.toggleClass('fold');
		if($el.hasClass('active')) {
//			$td.attr('rowspan', 2);
			$xx.closest('tr').hide();
			console.log($xx);
			if($xx.hasClass('active')){
				$xx.closest('tr').show()
			}
		} else {
//			$td.attr('rowspan', $td.attr('data-policylength'));
			$xx.closest('tr').show();
		}
		$el.toggleClass('active');
	}
});