/**
 * Created by zed on 15/12/26.
 */
app.controller('View1Ctrl',['$scope', function ($scope) {

}])