# Angular 动态化加载脚本demo

一个为angular量身定制的脚本加载器,小巧玲珑的它只有 <b>15KB</b>, <b>15KB</b>!它就是`ocLazyLoad`


## Getting Started

执行: `bower install`

## About ocLazyLoad

Find all the documentation (and more) on <b>[https://oclazyload.readme.io]</b>

## Contact

For more information on AngularJS please check out http://angularjs.org/

[git]: http://git-scm.com/
[bower]: http://bower.io
[npm]: https://www.npmjs.org/
[node]: http://nodejs.org
[protractor]: https://github.com/angular/protractor
[jasmine]: http://jasmine.github.io
[karma]: http://karma-runner.github.io
[travis]: https://travis-ci.org/
[http-server]: https://github.com/nodeapps/http-server
