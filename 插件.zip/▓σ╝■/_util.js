/*
 *  工具箱
 */

var Util = {
    specialstr: /[`~!@#$^&*()-+=|{}':;',\\.。?<>_]/, // 判断是否有特殊字符
    submitDialog: $.dialog({
        buttons: {
            '确定': function() {
                this.close();
            }
        }
    }),
    /**
     * [setLoading 设置正在加载弹窗]
     * @param {[type]} content [弹窗提示]
     */
    setLoading: function(content) {
        return $.dialog({
            autoOpen: false,
            closeBtn: false,
            style: 'tip',
            closeTime: 1000000,
            width: 220,
            content: '<span class="loading"></span><span class="loading-tips">' + content + '</span>' //内容
        });
    },
    /**
     * [showTips 带标题弹窗]
     * @param  {[type]} t [弹窗标题]
     * @param  {[type]} c [弹窗内容]
     * @return {[type]}   [description]
     */
    showTips: function(t,c) {
        var tips = $.dialog({
            buttons: {
                '确定': function() {
                    this.close();
                }
            },
            title: t
        });
        $("input").blur();
        var tdialog = setTimeout(function() {
            tips.open(c);
        }, 300);
    },
    /**
     * [getYMD 日期切割机 年、月、日]
     * @param  {[type]} date [description]
     * @return {[type]}      [description]
     */
    getYMD: function(date) { // 日期切割机 年、月、日
        var obj = {};
        var array = date.split("-");
        var nbirth = new Date(parseInt(array[0]), parseInt(array[1]) - 1, parseInt(array[2]));
        obj.yy = nbirth.getFullYear();
        obj.mm = nbirth.getMonth();
        obj.dd = nbirth.getDate();
        return obj;
    },
    /**
     * 验证姓名
     */
    validateName: function(name) {
        var self = this;

        var regen = /^[a-zA-Z]+\/[a-zA-Z]+$/; // 英文
        var regcn = /[\u4E00-\u9FA5]/; // 中文
        var regcn2 = /[\u4E00-\u9FA5]{2,}/; // 中文
        var reguncn = /^[a-zA-Z\u4E00-\u9FA5\/]+$/; // 汉字拼音
        var regid = /(^\d{15}$)|(^\d{17}([0-9]|X)$)/;

        var obj = {
            flag: true, // 默认输入姓名正常
            tips: "" // 提示语
        };

        if (!name) {
            obj.flag = false;
            obj.tips = "请输入出游人姓名";
        } else if (self.specialstr.test(name)) {
            obj.flag = false;
            obj.tips = "姓名不能输入特殊符号";
        } else if (name.length > 26) {
            obj.flag = false;
            obj.tips = "英文姓名不超过26个字符，如姓名过长请使用缩写";
        } else if (!regcn.test(name)) {
            if (!regen.test(name)) {
                obj.flag = false;
                obj.tips = "请用“/“将姓与名隔开，如“wang/er”，不区分大小写";
            }
        } else if (!reguncn.test(name)) {
            obj.flag = false;
            obj.tips = "中文姓名请只包含中文和拼音";
        }

        return obj;
    },
    /**
     * [validateCertNo 验证证件号]
     */
    validateCertNo: function(certtype,certno) {
        var self = this;

        var obj = {
            flag: true, // 默认输入证件号正常
            tips: "" // 提示语
        };

        if (certtype == 1) {
            if (!certno) {
                obj.flag = false;
                obj.tips = "请输入身份证号";
            } else if (!Util.ValidId(certno)) {
                obj.flag = false;
                obj.tips = "请输入正确的身份证号";
            }
        } else if (certtype == 2 || certtype == 6 || certtype == 7 || certtype == 8 || certtype == 9) {
            if (!certno) {
                obj.flag = false;
                obj.tips = "请输入证件号码";
            } else if (self.specialstr.test(certno)) {
                obj.flag = false;
                obj.tips = "证件号不能有特殊字符,请重新输入";
            }
        }

        return obj;
    },
    /**
     * [validateAge 验证年龄]
     * 满80岁是根据回团日期来的,如果回来的时候满80岁不允许预订该产品
     */
    validateAge: function(trav, backstr, birth, todayDate,isSetContract) {
        var self = this;

        var obj = {
            flag: true, // 默认年龄验证成功
            tips: "" // 提示语
        };

        var obj_t = self.getYMD(trav); // 出团日期
        var obj_h = self.getYMD(backstr); // 回团日期
        var obj_b = self.getYMD(birth); // 生日
        var obj_n = self.getYMD(todayDate); //今天的日期

        if (obj_t.yy < obj_b.yy + 2 || (obj_t.yy == obj_b.yy + 2 && obj_t.mm < obj_b.mm) ||
            (obj_t.yy == obj_b.yy + 2 && obj_t.mm == obj_b.mm && obj_t.dd < obj_b.dd)) {
            obj.flag = false;
            obj.tips = "预订游客年龄不能小于2岁";
        } else if (obj_h.yy > obj_b.yy + 80 || (obj_h.yy == obj_b.yy + 80 && obj_h.mm > obj_b.mm) ||
            (obj_h.yy == obj_b.yy + 80 && obj_h.mm == obj_b.mm && obj_h.dd >= obj_b.dd)) {
            obj.flag = false;
            obj.tips = "抱歉！80周岁以上的出游人暂无法购买此产品.";
        }
         
        //设置为联系人的时候，验证联系人是否小于12周岁 
        if (isSetContract) {
            if (obj_n.yy < obj_b.yy + 12 || (obj_n.yy == obj_b.yy + 12 && obj_n.mm < obj_b.mm) ||
                (obj_n.yy == obj_b.yy + 12 && obj_n.mm == obj_b.mm && obj_n.dd < obj_b.dd)) {
                obj.flag = false;
                obj.tips = "联系人年龄不能小于12周岁";
            }
        }

        return obj;
    },
    //利用算法验证身份证号
    ValidId: function(idcard) {
        var Wi = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2, 1]; // 加权因子;
        var ValideCode = [1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2]; // 身份证验证位值，10代表X;
        var flag = false;

        if (idcard.length == 15) {
            return isValidityBrithBy15IdCard(idcard);
        } else if (idcard.length == 18) {
            var a_idCard = idcard.split(""); // 得到身份证数组
            if (isValidityBrithBy18IdCard(idcard) && isTrueValidateCodeBy18IdCard(a_idCard)) {
                return true;
            }
            return false;
        }
        return false;

        function isTrueValidateCodeBy18IdCard(a_idCard) {
            var sum = 0; // 声明加权求和变量
            if (a_idCard[17].toLowerCase() == 'x') {
                a_idCard[17] = 10; // 将最后位为x的验证码替换为10方便后续操作
            }
            for (var i = 0; i < 17; i++) {
                sum += Wi[i] * a_idCard[i]; // 加权求和
            }
            valCodePosition = sum % 11; // 得到验证码所位置
            if (a_idCard[17] == ValideCode[valCodePosition]) {
                return true;
            }
            return false;
        }

        function isValidityBrithBy18IdCard(idCard18) {
            var year = idCard18.substring(6, 10);
            var month = idCard18.substring(10, 12);
            var day = idCard18.substring(12, 14);
            var temp_date = new Date(year, parseFloat(month) - 1, parseFloat(day));
            // 这里用getFullYear()获取年份，避免千年虫问题
            if (temp_date.getFullYear() != parseFloat(year) || temp_date.getMonth() != parseFloat(month) - 1 || temp_date.getDate() != parseFloat(day)) {
                return false;
            }
            return true;
        }

        function isValidityBrithBy15IdCard(idCard15) {
            var year = idCard15.substring(6, 8);
            var month = idCard15.substring(8, 10);
            var day = idCard15.substring(10, 12);
            var temp_date = new Date(year, parseFloat(month) - 1, parseFloat(day));
            // 对于老身份证中的你年龄则不需考虑千年虫问题而使用getYear()方法
            if (temp_date.getYear() != parseFloat(year) || temp_date.getMonth() != parseFloat(month) - 1 || temp_date.getDate() != parseFloat(day)) {
                return false;
            }
            return true;
        }
    },
    //将v.CustomerCertNo取字符串，首位保留，其它换为*
    encryptCertNo: function(CertNo) {
        var NoLen = CertNo.length;
        var NoArr = CertNo.split("");
        var newArr = new Array();
        for (var i = 0; i < NoLen; i++) {
            if (NoLen > 2 && (i == 0 || i == NoLen - 1)) {
                newArr[i] = NoArr[i];
            } else {
                newArr[i] = '*'
            }

        }
        newstr = newArr.join("");
        return newstr;
    },
    //根据身份证号获得出生日期
    GetBirthday: function(psidno) {
        var birthdayno, birthdaytemp;
        if (psidno.length == 18) {
            birthdayno = psidno.substring(6, 14)
        } else if (psidno.length == 15) {
            birthdaytemp = psidno.substring(6, 12)
            birthdayno = "19" + birthdaytemp
        } else {
            return false;
        }
        return birthdayno.substring(0, 4) + "-" + birthdayno.substring(4, 6) + "-" + birthdayno.substring(6, 8);
    },
    //根据身份证号获得性别
    Getsex: function(psidno) {
        var sexno;
        if (psidno.length == 18) {
            sexno = psidno.substring(16, 17)
        } else if (psidno.length == 15) {
            sexno = psidno.substring(14, 15)
        } else {
            return false;
        }
        return sexno % 2 == 0 ? "F" : "M";
    },
    /**
     *  填写订单的时候根据出发时间判断是否儿童,提交订单的时候根据回团日期判断是否成年:比如去程是儿童就是儿童价,回来是成人就是成人价
     *  [2,80)岁的人能购买
     * @param  {[type]} temp_BirthDay [出生日期]
     * @param  {[type]} compareDate   [如果是跟出发时间比较就传出发时间,回团时间比较就传回团时间]
     * @return {[type]}               [description]
     */
    getCustomerType: function(temp_BirthDay, compareDate) {
        //比较时间
        var compareDate = compareDate;
        var array1 = compareDate.split("-");
        var ntrav = new Date(parseInt(array1[0]), parseInt(array1[1]) - 1, parseInt(array1[2]));
        var ty = ntrav.getFullYear();
        var tm = ntrav.getMonth();
        var td = ntrav.getDate();
        // 出生 b
        var str = temp_BirthDay;
        var array2 = str.split("-");
        var nbirth = new Date(parseInt(array2[0]), parseInt(array2[1]) - 1, parseInt(array2[2]));
        var by = nbirth.getFullYear();
        var bm = nbirth.getMonth();
        var bd = nbirth.getDate();

        if (ty < by + 12 || (ty == by + 12 && tm < bm) || (ty == by + 12 && tm == bm && td < bd)) {
            return 2; //儿童
        } else {
            return 1; //成人
        }
    },
    // 判断一个数组中是否有想同的值
    isHasSameData: function(arr) {
        var that = arguments.callee;
        var bResult = false;
        var _call = function(arr) {
            if (!arr.length) {
                return;
            }
            for (var i = 1; arr[i]; i++) {
                if (arr[0] === arr[i]) {

                    bResult = true;
                    return;
                }
            }
            if (!bResult) {
                arr.splice(0, 1);
                _call.call(this, arr);
            }
        };
        _call.call(this, arr);
        return bResult;
    },
    /**
     * [validTravlersCount 验证出游人的个数是否符合订单人数]
     * @param  {[type]} arrTravlers [选择的出游人]
     * @param  {[type]} total_adult [订单总成人数]
     * @param  {[type]} all_child   [订单总儿童数]
     */
    validTravlersCount: function(arrTravlers,total_adult,all_child) {
        var self = this;

        var adultCount = 0, //当前成人变量
            childCount = 0; //当前儿童变量
        $.each(arrTravlers, function(index, item) {
            item.CustomerType == 1 ? adultCount++ : childCount++;
        });
        if (adultCount > total_adult) {
            self.submitDialog.open("您多填了" + (adultCount - total_adult) + "个成人");
            return false;
        } else if (adultCount < total_adult) {
            self.submitDialog.open("您还少" + (total_adult - adultCount) + "个成人");
            return false;
        } else if (childCount > all_child) {
            self.submitDialog.open("您多填了" + (childCount - all_child) + "个儿童");
            return false;
        } else if (childCount < all_child) {
            self.submitDialog.open("您还少" + (all_child - childCount) + "个儿童");
            return false;
        }
        return true;
    },
    getWXMemberId: function() {
        var wxUser = $.cookie("WxUser");
        var userid = "";
        if (wxUser) {
            var useridStrArray = wxUser.split("userid=");
            if (useridStrArray.length == 2) {
                wxUser = useridStrArray[1];
                useridStrArray = wxUser.split("&");
                userid = useridStrArray[0];
            }
        }
        return userid;
    },
    //今天的日期
    getTodayDate: function(strTime) {
        var date = new Date(strTime);
        return date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
    }
};
Util.detailLoading = Util.setLoading("正在加载"),
Util.submitLoading = Util.setLoading("正在提交"),
module.exports = Util;